/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adopcion;
import java.util.ArrayList;
import vista.Vista;

public class Animal {
  private  String Tipo,Nombre,Raza,Color,Adicional;
  private int Edad;
    
    public Animal() {
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getRaza() {
        return Raza;
    }

    public void setRaza(String Raza) {
        this.Raza = Raza;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }

    public String getAdicional() {
        return Adicional;
    }

    public void setAdicional(String Adicional) {
        this.Adicional = Adicional;
    }


    
    public Animal(String Tipo, String Nombre, String Raza, String Color, int Edad, String Adicional) {
        this.Tipo = Tipo;
        this.Nombre = Nombre;
        this.Raza = Raza;
        this.Color = Color;
        this.Edad = Edad;
        this.Adicional = Adicional;
    }
    

    
    
  
}
